<?php
/*
  Plugin Name: tmo.GoogleIOT
*/

defined( 'ABSPATH' ) || die( 'Unauthorized Access' );

add_shortcode('tmo.googletrends','callback_googletrends');

function callback_googletrends(){

//
// Backend url
//	
$api = 'https://thomasmoor.org/getgoogleiot';
$log = 'tmo.googleIOT.log';
  
$h = '<form method="post">';
$h .= '<label>Keywords (up to 5, separated by commas): </label>';
$h .= '<input type="text" name="keywords"/> ';
$h .= '<input type="submit" name="submit" value="Google Trends"/>';
  
if(isset($_POST['submit']) and isset($_POST['keywords']) and $_POST['keywords'] != ''){

  // $h .= '<br> api:' . $api;
  // $h .= '<br>keywords: ' . $_POST['keywords'];
  
  $body = array(
    'keywords' => sanitize_text_field($_POST['keywords'])
  );
  
  $arguments=array(
    'body'   => $body,
  );
  
  // API Call  
  $response = wp_remote_post($api,$arguments);
  $code=$response['response']['code'];
  $message=$response['response']['message'];
  if($code != '200'){
    $h .= '<br>Could not connect to API: ' . $api;
    $h .= '<br>Response: code: '.$code . ' message: ' . $message;
  return $h;
  }
    
  $body=$response['body'];
  // file_put_contents($log, '$body: ' . $body, FILE_APPEND);

  $results=json_decode($body,true);
  // $results = $decode['results'];
  
  // Set the results
  $h .= '<table border="1">';
  $h .= '<tr>';
  $h .= '<td>Keyword</td>';
  $h .= '<td>Last</td>';
  $h .= '<td>Max</td>';
  $h .= '<td>Min</td>';
  $h .= '<td>MA Long</td>';
  $h .= '<td>MA Med</td>';
  $h .= '<td>MA Short</td>';
  $h .= '</tr>';
  foreach ($results as $row):
    $h .= '<tr>';
	$h .= '<td>' . $row['keyword'] . '</td>';
	$h .= '<td>' . $row['last'] . '</td>';
	$h .= '<td>' . $row['max'] . '</td>';
	$h .= '<td>' . $row['min'] . '</td>';
	$h .= '<td>' . $row['mal'] . '</td>';
	$h .= '<td>' . $row['mam'] . '</td>';
	$h .= '<td>' . $row['mas'] . '</td>';
    $h .= '</tr>';
  endforeach;
  $h .= '</table>';  

} else if(isset($_POST['results'])) {
  $results=$_POST['results'];
} else {
  $results='';
}

// Download
if (isset($_POST['download'])){
  ob_clean();
  ob_end_clean();
  ob_start(null, 0, PHP_OUTPUT_HANDLER_CLEANABLE);
  header('Content-Type: text/csv');
  header('Content-Disposition: attachment; filename="thomasmoor.org.csv"');
  header('Pragma: no-cache');    
  header('Expires: 0');
  $message = "";
  $fp = fopen('php://output', 'w');
  
  $s = '';
  $s .= 'Keyword,Last,Max,Min,MA Long,MA Med,MA Short\n';
  foreach ($results as $row):
    $h .= ',' . $row['keyword'];
	$h .= ',' . $row['last'];
	$h .= ',' . $row['max'];
	$h .= ',' . $row['min'];
	$h .= ',' . $row['mal'];
	$h .= ',' . $row['mam'];
	$h .= ',' . $row['mas'];
    $h .= '\n';
  endforeach;
  
  fwrite($fp, $s);
}
  
$h .= "<br/>";
$h .= '<input type="submit" name="download" value="Download"/>';
    
$h .= '</form>';
  
return $h;

} // callback

?>